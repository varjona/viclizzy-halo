### Get Token:
  https://portal.socketxp.com/#/authtoken

### Authenticate and connect the SocketXP agent with the SocketXP Cloud Gateway:
  socketxp login "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjI2MDcyMjAxNjksImtleSI6IjE3OWZhZWMzLTdmY2ItNGQwMy04MDVlLTAzMWVlYjdiMjQ2YiJ9.XmRBCtX14EoYHkG8ehJLtq7IHacTOH-k_vpxjhDUPAU" --iot-device-name "flask-app-halo" --iot-device-group "VicLizzy"

### Public URL for your IoT Web Service:
$ socketxp connect http://localhost:5000

  Connected to SocketXP Cloud Gateway.
  Public URL -> https://test-user-a29dfe42e3.socketxp.com