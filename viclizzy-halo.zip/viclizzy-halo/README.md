# viclizzy-halo
Computer vision and LED Embedded System Project. More details to come...

## Clone this Repo:

git  clone git@github.com:victorarjona2/viclizzy-halo.git

## install Opencv-python

- Windows

  pip install opencv-python

- _install Opencv-python on Linux or Mac_

  pip3 install opencv-python

## Run the code

- windows: :point_down:

  python run_halo.py